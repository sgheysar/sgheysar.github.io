</div><!--wrapper-->
<div class="clear"></div>
<div id="footer">
	<div id="footer-inside">
		<p>
		طراحی توسط <a href="http://zww.me" title="designed by zwwooooo">zBench</a> | ترجمه به فارسی توسط <a href="http://blog.naimi.ir" title="مهدی نعیمی">مهدی نعیمی</a>
		</p>
		<span id="back-to-top">&Delta; <a href="#nav" rel="nofollow" title="Back to top"><?php _e('بالا'); ?></a></span>
	</div>
</div><!--footer-->
<?php wp_footer(); ?>
</body>
</html>