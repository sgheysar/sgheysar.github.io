<?php get_header(); $options = get_option('zBench_options'); ?>
<div id="content">
	<?php the_post(); ?>
	<div class="page-title">
		<?php if ( is_day() ) : ?>
			<h1><?php printf((__('بایگانی روزانه:').' <span>%s</span>'),get_the_time(get_option('date_format'))) ?></h1>
		<?php elseif ( is_month() ) : ?>
			<h1><?php printf((__('بایگانی ماهانه:').' <span>%s</span>'),get_the_time('F Y')) ?></h1>
		<?php elseif ( is_year() ) : ?>
			<h1><?php printf((__('بایگانی سالانه:').' <span>%s</span>'),get_the_time('Y')) ?></h1>
		<?php elseif ( is_category() ) : ?>
			<h1><?php printf((__('بایگانی موضوعی:').' <span>%s</span>'),single_cat_title('',false)) ?></h1>
		<?php elseif ( is_tag() ) : ?>
			<h1><?php printf((__('بایگانی برچسب‌ها:').' <span>%s</span>'),single_tag_title('',false)) ?></h1>
		<?php elseif ( isset($_GET['paged']) && !empty($_GET['paged']) ) : ?>
			<h1><?php _e('بایگانی وبلاگ'); ?></h1>
		<?php endif; ?>
	</div><?php rewind_posts(); ?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>"><!-- post div -->
		<h2 class="title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
		<div class="post-info-top">
			<span class="post-info-date"><?php _e('توسط:'); ?> <?php the_author(); ?> <?php _e('در:'); ?> <?php the_time(get_option( 'date_format' )); ?> <?php edit_post_link(__('ویرایش'), '[', ']'); ?></span>
			<span id="gotocomments"><?php comments_popup_link(__('بدون نظر'), '1 '.__('1 نظر'), '% '.__('نظر')); ?><?php if(function_exists('the_views')) { echo " | ";the_views(); } ?></span>
		</div>
		<div class="clear"></div>
		<div class="entry">
			<?php if ( $options['excerpt_check']=='true' ) { the_excerpt(__('ادامه')); } else { the_content(__('ادامه')); } ?>
		</div><!-- END entry -->
	</div><!-- END post -->
	<?php endwhile; else: ?>
	<div class="post post-single">
		<h2 class="title title-single"><a href="#" title="<?php _e('ارور 404 - پیدا نشد.'); ?>"><?php _e('ارور 404 - پیدا نشد.'); ?></a></h2>
		<div class="post-info-top" style="height:1px;"></div>
		<div class="entry">
			<p><?php _e('متاسفیم، مطلبی که به دنبال آن هستید پیدا نشد.'); ?></p>
			<h3><?php _e('مطالب اتفاقی'); ?></h3>
			<ul>
				<?php
					$rand_posts = get_posts('numberposts=5&orderby=rand');
					foreach( $rand_posts as $post ) :
				?>
				<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<h3><?php _e('ابرچسب'); ?></h3>
			<?php wp_tag_cloud('smallest=9&largest=22&unit=pt&number=200&format=flat&orderby=name&order=ASC');?>
		</div><!--entry-->
	</div><!--post-->
	<?php endif; ?>
<?php
if(function_exists('wp_page_numbers')) {
	wp_page_numbers();
}
elseif(function_exists('wp_pagenavi')) {
	wp_pagenavi();
} else {
	global $wp_query;
	$total_pages = $wp_query->max_num_pages;
	if ( $total_pages > 1 ) {
		echo '<div id="pagination">';
			posts_nav_link(' | ', __('صفحه‌ی قبلی'), __('صفحه‌ی بعدی'));
		echo '</div>';
	}
}
?>
</div><!--content-->
<?php get_sidebar() ?>
<?php get_footer() ?>