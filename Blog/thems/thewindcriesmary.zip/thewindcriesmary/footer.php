		</div>
		</div>
	</div>

</div>	
<div id="footer">
	<?php do_action('wp_footer'); ?>
</div>

</body>
</html>