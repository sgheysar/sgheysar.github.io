		<div id="banner">
			<div id="banner-inner" class="pkg">
				<h1 id="banner-header"><a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a></h1>
				<h2 id="banner-description"><?php bloginfo('description'); ?></h2>
			</div>
		</div>