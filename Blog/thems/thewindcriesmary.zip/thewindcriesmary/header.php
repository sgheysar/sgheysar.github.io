<?php load_theme_textdomain('twcm'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="sixapart-standard">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo('charset'); ?>" />
   <meta name="generator" content="Wordpress" />
  <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/style.css" type="text/css" />
   <title><?php bloginfo(); ?></title>  
<?php wp_head(); ?> 
</head>


