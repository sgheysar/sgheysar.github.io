﻿<?php if ( !is_404() ) {?></div>
<div class="hr"></div>
<div id="footer">
<div class="wrapper">
	<p>
		© 2010~<?php echo date('Y'); ?> <a href="<?php echo get_settings('home'); ?>"><?php bloginfo('name'); ?></a><br />
		قدرت گرفته توسط   : <a href="http://www.wp-persian.com/">وردپرس پارسی</a><br />
		طراحی شده توسط : <a href="http://utombox.com">Utom</a><br />
		ترجمه و ویرایش توسط : <a href="http://www.7thline.ir" title="مسعود گلچین">مسعود گلچین</a>	
		

		 
		<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
	</p>
</div>
</div>
</div><?php }?>
<?php /* "Just what do you think you're doing Dave?" */ ?>
<?php wp_footer(); ?>
</body>
</html>
