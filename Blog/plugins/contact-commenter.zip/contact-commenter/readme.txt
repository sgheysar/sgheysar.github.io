=== Plugin Name ===
Contributors: moallemi
Donate link: http://www.moallemi.ir/blog/1388/12/27/%d9%87%d8%af%db%8c%d9%87-%da%a9%d8%a7%d9%88%d8%b4%da%af%d8%b1-%d9%85%d9%86%d8%a7%d8%b3%d8%a8%d8%aa-%d8%b3%d8%a7%d9%84-%d9%86%d9%88-%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3/
Tags: comment,comments, mail, admin, کاوشگر
Requires at least: 2.8
Tested up to: 3.0
Stable tag: "trunk"

This Plugin lets you send email messages to individual or a group of commenters.

== Description ==

This Plugin lets you send email messages to individual or a group of commenters. It lets Administrator to see who has wrote more comments on his post and mail to commenters.
You can also ansewer each comment in the admin panel of wordpress by sending a private reply to each commenter.

**What's New in version 0.7**

	* Now you can send private Reply directly from your wordpress admin panel.
	* Contact commenters form added as a submenu to the edit-comments page.



**Translations**

* Persian - [Reza Moallemi](http://www.moallemi.ir/)


== Installation ==

1. Upload `contact-commenter` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. A preview of "Private Reply" Button in wordpress admin panel

== Changelog ==

= 0.7 =
* Now you can send private Reply directly from your wordpress admin panel.
* Contact commenters form added as a submenu to the edit-comments page.

= 0.6 =
* Fixed a bug on sending HTML messages.

= 0.5 =
* base version



