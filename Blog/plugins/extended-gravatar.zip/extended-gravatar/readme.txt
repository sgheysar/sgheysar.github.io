=== Plugin Name ===
Contributors: moallemi
Donate link: http://www.moallemi.ir/en/blog/2010/06/03/google-reader-stats-for-wordpress/
Tags: Avatar, gravatar, hovercards, کاوشگر, moallemi
Requires at least: 3.1
Tested up to: 3.2.1
Stable tag: "trunk"

This plugin brings Hovercard popups for your commenters via Gravatar

== Description ==
This plugin brings Hovercard popups for your commenters and adds some cool fetures using gravatar.


== Installation ==

1. Upload `extended-gravatar` to the `/wp-content/plugins/` directory

1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. A sample of gravatar hovercard


== Changelog ==

= 0.6 =

* Add email invitation to commenters that do not enabled gravatar yet

= 0.5 =

* base version







