=== Plugin Name ===
Contributors: moallemi
Donate link: http://www.moallemi.ir/en/blog/2010/06/03/google-reader-stats-for-wordpress/
Tags: google, google reader, stats, stat, statistic, widget, like, کاوشگر, لایک, لایک خور, گوگل پلاس, پلاس وان, google +1, گودر
Requires at least: 2.9
Tested up to: 3.2.1
Stable tag: "trunk"

This plugin adds the Google Reader Stats (+1 count/View count) to your blog posts. 

== Description ==
This plugin adds the Google Reader Stats to your blog. GRS measures the +1s and views count of each blog feed item on Google Reader and displays it on your blog . The GRS Widget enables readers to easily see the blog’s best content, with the highest overall +1s or views on Google Reader. 

Put the `<?php if (function_exists( 'the_grs_plusones' )) the_grs_plusones(); ?>` code for post +1s and  `<?php if (function_exists( 'the_grs_views' )) the_grs_views(); ?>` for post views in your template files (index.php, single.php, archive.php) to show +1/view count.


**Translations**

* Persian - [Reza Moallemi](http://www.moallemi.ir/)


**What's New in version 1.4**
	
	* Add Support for new google reader interface and fetures
	* Add Support for Google +1
	* Improve Graph performance for viewing feed stats



== Installation ==

1. Upload `google-reader-stats` to the `/wp-content/plugins/` directory

1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Options Page 

1. Widget settings

1. Output of widget in persian language



== Changelog ==

= 1.4 =

* Add Support for new google reader interface and fetures
* Add Support for Google +1
* Improve Graph performance for viewing feed stats

= 1.2.0.1 =

* Fixed a bug where feed view stats did not count views correctly

= 1.2 =

* Add Graph for viewing feed stats

= 1.0 =

* Add support for counting likes of 4 feed output

= 0.8.1 =

* Fixed a bug where the plugin did not work with **wp-jalali** plugin 

= 0.8 =
* Compatible with WordPress 3.0
* Compatible with new Google Reader API
* Add support for post views for each post on feed
* Add a stats page for Google Reader Stats in the wordpress Dashboard


= 0.5.1 =

* Add a '+' when post likes are upper than 100


= 0.5 =

* base version







