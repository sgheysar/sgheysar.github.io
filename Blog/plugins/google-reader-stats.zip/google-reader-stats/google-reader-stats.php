<?php
/*
  Plugin Name: Google Reader Stats
  Plugin URI: http://www.moallemi.ir/en/blog/2010/06/03/google-reader-stats-for-wordpress/
  Description: This plugin adds the Google Reader Stats (+1 count and Post Views) to your blog posts. Put the <code>&lt;?php if (function_exists( 'the_grs_plusones' )) the_grs_plusones(); ?&gt;</code> code for post +1s and  <code>&lt;?php if (function_exists( 'the_grs_views' )) the_grs_views(); ?&gt;</code> for post views in your template files (index.php, single.php, archive.php) to show +1/view count.
  Version: 1.4
  Author: Reza Moallemi
  Author URI: http://www.moallemi.ir/blog
  Text Domain: google-reader-stats
  Domain Path: /languages/
 */


load_plugin_textdomain('google-reader-stats', NULL, dirname(plugin_basename(__FILE__)) . "/languages");

add_action('admin_menu', 'google_reader_stats_menu');

function google_reader_stats_menu() {
    add_options_page('Google Reader Stats Options', __('Google Reader Stats', 'google-reader-stats'), 10, 'google-reader-stats', 'google_reader_stats_options');
    add_submenu_page('index.php', __('Google Reader Stat', 'google-reader-stats'), __('Google Reader Stat', 'google-reader-stats'), 10, 'google-reader-stats/google-reader-view-stats.php');
}

function get_google_reader_stats_options() {
    $plugin_url = get_option('siteurl') . '/wp-content/plugins/' . plugin_basename(dirname(__FILE__));
    $google_reader_stats_options = array(
        'plusone_counter_enabled' => 'true',
        'show_plusone_column' => 'true',
        'plusone_column_type' => 'button',
        'last_update' => 'N/A',
        'interval' => '2',
        'plusone_minimum' => '0',
        'most_liked_template' => '<li><a href="%POST_URL%"  title="%POST_TITLE%">%POST_TITLE%</a> - <img align="absmiddle" src="' . $plugin_url . '/grs_plusone_small.png" alt="like" /> %PLUSONE_COUNT% ' . __('likes', 'google-reader-stats') . '</li>',
        'post_plusone_template' => ' <img align="absmiddle" src="' . $plugin_url . '/grs_plusone_small.png" alt="like" /> %PLUSONE_COUNT% ',
        'view_minimum' => '0',
        'most_viewd_template' => '<li><a href="%POST_URL%"  title="%POST_TITLE%">%POST_TITLE%</a> - %VIEW_COUNT% ' . __('views', 'google-reader-stats') . '</li>',
        'post_view_template' => ' %VIEW_COUNT% ' . __('feed views', 'google-reader-stats'),
        'plugin_status' => 'READY_FOR_CHECK',
        'show_plugin_url' => 'true',
        'show_author_url' => 'true',
        'plugin_version' => '1.4');
    $google_reader_stats_save_options = get_option('google_reader_stats_options');
    if (!empty($google_reader_stats_save_options)) {
        foreach ($google_reader_stats_save_options as $key => $option)
            $google_reader_stats_options[$key] = $option;
    }
    update_option('google_reader_stats_options', $google_reader_stats_options);
    return $google_reader_stats_options;
}

function GoogleReaderStats() {

    //delete_option('google_reader_stats_options');
    $options = get_google_reader_stats_options();

    if ($options['plusone_counter_enabled'] == "true")
        add_action('wp_footer', 'grs_check_for_update');

    if ($options['plugin_version'] != "1.4") {
        delete_option('google_reader_stats_options');
        grs_install();
        $options['plugin_version'] = '1.4';
        update_option('google_reader_stats_options', $options);
    }
    if ($options['plugin_status'] == "CURL_MISSED" and $options['plusone_counter_enabled'] == 'true') {
        $options['plusone_counter_enabled'] = 'false';
        update_option('google_reader_stats_options', $options);
    }

    add_filter('the_content', 'grs_add_counter_to_feed', 10000);
    
    if($options['show_plusone_column'] == 'true') {
        add_filter('manage_posts_columns', 'grs_manage_posts_columns');
        add_action('manage_posts_custom_column', 'grs_manage_posts_custom_column');
    }
}

register_activation_hook(__FILE__, 'grs_install');

function grs_install() {
    global $wpdb;

    $table_name = $wpdb->prefix . "grs_main";
    if ($wpdb->get_var("show tables like '$table_name'") != $table_name) {
        $charset_collate = '';
        if ($wpdb->has_cap('collation')) {
            if (!empty($wpdb->charset))
                $charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
            if (!empty($wpdb->collate))
                $charset_collate .= " COLLATE $wpdb->collate";
        }

        $sql = "CREATE TABLE " . $table_name . " (
					`post_id` bigint(20) NOT NULL,
					`date_visit` date NOT NULL,
					`visit` bigint(20) unsigned NOT NULL DEFAULT '1',
					PRIMARY KEY (`post_id`,`date_visit`)
				) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

function grs_check_for_update() {

    //print '<pre dir="ltr">';
    $options = get_google_reader_stats_options();
	

    //print_r($options);
    if (is_admin() and $options['plugin_status'] == 'UNCOMPLETED_OPTIONS') {
        //print "UNCOMPLETED_OPTIONS";
    } else if ($options['plugin_status'] != 'UNCOMPLETED_OPTIONS') {
        $current_date = date('Y-m-d H:i:s');
        $last_update = $options['last_update'];
        $interval = $options['interval'];
        //print "upd: $last_update \n";
        //print "now: $current_date \n";
        //print "int: $interval \n";
        //print date('Y-m-d H:i:s', strtotime(date("Y-m-d H:i:s", strtotime($last_update)) . " +$interval hours"))."\n";

        if (strtotime($current_date) >= strtotime(date("Y-m-d H:i:s", strtotime($last_update)) . " +$interval hours")) {
						grs_fetch_stats();
        }
        //else
        //{
        //	print 'not now';
        //}
        //print '</pre>';
    }
}

function google_reader_stats_options() {
    $grs_options = get_google_reader_stats_options();

    print '<pre dir="ltr">';
    //print_r($google_reader_stats_options);
    print '</pre>';

    $plugin_url = get_option('siteurl') . '/wp-content/plugins/' . plugin_basename(dirname(__FILE__));
    if (isset($_POST['update_google_reader_stats_settings'])) {
        $grs_options['plusone_counter_enabled'] = isset($_POST['plusone_counter_enabled']) ? $_POST['plusone_counter_enabled'] : 'false';
        
        $grs_options['show_plusone_column'] = isset($_POST['show_plusone_column']) ? $_POST['show_plusone_column'] : 'false';
        $grs_options['plusone_column_type'] = isset($_POST['plusone_column_type']) ? $_POST['plusone_column_type'] : 'button';
        

        $grs_options['interval'] = (isset($_POST['interval']) and $_POST['interval'] != '') ? intval($_POST['interval']) : '2';

        $grs_options['post_plusone_template'] = (isset($_POST['post_plusone_template']) and $_POST['post_plusone_template'] != '') ? $_POST['post_plusone_template'] : ' <img align="absmiddle" src="' . $plugin_url . '/grs_plusone_small.png" alt="like" /> %PLUSONE_COUNT% ';
        $grs_options['most_liked_template'] = (isset($_POST['most_liked_template']) and $_POST['most_liked_template'] != '') ? $_POST['most_liked_template'] : '<li><a href="%POST_URL%"  title="%POST_TITLE%">%POST_TITLE%</a> - %PLUSONE_COUNT% ' . __('likes', 'google-reader-stats') . '</li>';
        $grs_options['view_minimum'] = (isset($_POST['view_minimum']) and $_POST['view_minimum'] != '') ? intval($_POST['view_minimum']) : '0';
        $grs_options['post_view_template'] = (isset($_POST['post_view_template']) and $_POST['post_view_template'] != '') ? $_POST['post_view_template'] : ' %VIEW_COUNT% ' . __('feed views', 'google-reader-stats');
        $grs_options['most_viewd_template'] = (isset($_POST['most_viewd_template']) and $_POST['most_viewd_template'] != '') ? $_POST['most_viewd_template'] : '<li><a href="%POST_URL%"  title="%POST_TITLE%">%POST_TITLE%</a> - %VIEW_COUNT% ' . __('views', 'google-reader-stats') . '</li>';
        $grs_options['show_plugin_url'] = isset($_POST['show_plugin_url']) ? $_POST['show_plugin_url'] : 'false';
        $grs_options['show_author_url'] = isset($_POST['show_author_url']) ? $_POST['show_author_url'] : 'false';

        if ($grs_options['plugin_status'] == 'CURL_MISSED') {
            if (function_exists('curl_init')) {

                $grs_options['plugin_status'] = 'READY_FOR_CHECK';
            }
        }


        update_option('google_reader_stats_options', $grs_options);
        if ($grs_options['plusone_counter_enabled'] == "true")
            grs_check_for_update();
        ?>
        <div class="updated">
            <p><strong><?php _e("Settings Saved.", "google-reader-stats"); ?></strong></p>
        </div>
        <?php
    }
    $grs_options = get_google_reader_stats_options();
    $last_update = $grs_options['last_update'];
    $interval = $grs_options['interval'];
    ?>
    <style>
        .error {
            color:red !important;
            border-color:#FF9797 !important;
        }
    </style>
    <div class="wrap">
        <div id="icon-options-general" class="icon32"><br /></div>
        <h2><?php _e('Google Reader Stats Settings', 'google-reader-stats'); ?></h2>
        <form id="grs_mainform" method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" >
            <h3><?php _e('Update Status:', 'google-reader-stats'); ?></h3>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('+1 Counter: ', 'google-reader-stats'); ?> </th>
                    <td>
                        <label>
                            <input name="plusone_counter_enabled" value="true" onchange="hideAccount();" type="checkbox" <?php
    if ($grs_options['plusone_counter_enabled'] == 'true')
        echo ' checked="checked" '; if ($grs_options['plugin_status'] == "CURL_MISSED")
        echo ' disabled="disabled" ';
    ?> /> <?php _e('Enable +1 counter.', 'google-reader-stats'); ?></label> <br />
                        <span class="description">
                            <?php _e('This module is required for +1 Widgets and Sorting posts by +1 count ', 'google-reader-stats'); ?>
                        </span> <br />
                        <span class="description error">
                            <?php
                            if ($grs_options['plugin_status'] == "CURL_MISSED")
                                _e('(cURL missed. You can not use +1 counter module. )', 'google-reader-stats');
                            ?>
                        </span>
                    </td>
                </tr>
            </table>
            <div id="divCounter" <?php if ($grs_options['plusone_counter_enabled'] != "true")
                            echo "style='display:none;'"; ?>>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e('Update Freq. (hour): ', 'google-reader-stats'); ?>   </th>
                        <td>
                            <input style="direction:ltr;width:25px;" id="interval" name="interval" type="text" value="<?php echo $grs_options['interval']; ?>" /> 
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Current time: ', 'google-reader-stats'); ?> </th>
                        <td style="direction:ltr;text-align:right;"><?php print grs_date('Y-m-d H:i:s'); ?> </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Last Update: ', 'google-reader-stats'); ?> </th>
                        <td style="direction:ltr;text-align:right;"><?php print grs_date('Y-m-d H:i:s', $grs_options['last_update']); ?></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php _e('Next update: ', 'google-reader-stats'); ?> </th>
                        <td style="direction:ltr;text-align:right;">
                            <?php if ($grs_options['last_update'] != 'N/A')
                                print grs_date('Y-m-d H:i:s', strtotime(date("Y-m-d H:i:s", strtotime($last_update)) . " +$interval hours"), false); ?>
                        </td>
                    </tr>
                </table>
            </div>
            <h3><?php _e('Admin Posts Page: ', 'google-reader-stats'); ?></h3>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Show +1 Count', 'google-reader-stats'); ?> </th>
                    <td>
                        <label>
                            <input name="show_plusone_column" value="true" type="checkbox" <?php  if ($grs_options['show_plusone_column'] == 'true') echo ' checked="checked" '; ?> /> <?php _e('Add a +1 counter Column', 'google-reader-stats'); ?></label> <br />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('+1 Button Type', 'google-reader-stats'); ?> </th>
                    <td>
                        <label>
                            <input name="plusone_column_type" value="button" type="radio" <?php  if ($grs_options['plusone_column_type'] == 'button') echo ' checked="checked" '; ?> /> <?php _e('Default Google +1 button', 'google-reader-stats'); ?></label> <span class="description">
                            <?php _e('shows default +1 button, you can share your posts and manage +1s' , 'google-reader-stats'); ?>
                        </span> <br />
                         <label>
                        <input name="plusone_column_type" value="number" type="radio" <?php  if ($grs_options['plusone_column_type'] == 'number') echo ' checked="checked" '; if ($grs_options['plugin_status'] == "CURL_MISSED")
        echo ' disabled="disabled" ';?> /> <?php _e('Only number of +1s', 'google-reader-stats'); ?></label>
                        <span class="description error">
                            <?php
                            if ($grs_options['plugin_status'] == "CURL_MISSED")
                                _e('(cURL missed. You can not use +1 counter module. )', 'google-reader-stats');
                            ?>
                        </span>
                    </td>
                </tr>
            </table>
            <h3><?php _e('Template Settings:', 'google-reader-stats'); ?></h3>
            <table class="form-table" style="width:auto">
                <tr valign="top">
                    <th scope="row"><?php _e('Show +1 count upper than: ', 'google-reader-stats'); ?>   </th>
                    <td>
                        <input style="direction:ltr;width:25px;" id="plusone_minimum" name="plusone_minimum" type="text" value="<?php echo $grs_options['plusone_minimum']; ?>" /> 
                        <span class="description">
                            <?php _e('To Show +1 count on posts', 'google-reader-stats'); ?>
                        </span>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Show feed views upper than: ', 'google-reader-stats'); ?> </th>
                    <td>
                        <input style="direction:ltr;width:25px;" id="view_minimum" name="view_minimum" type="text" value="<?php echo $grs_options['view_minimum']; ?>" /> 
                        <span class="description">
                            <?php _e('To Show feed views on posts', 'google-reader-stats'); ?>
                        </span>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <b><?php _e('Post +1 count template:', 'google-reader-stats'); ?></b><br />
                        <?php _e('Allowed Variables:', 'google-reader-stats'); ?><br />
                        						- %PLUSONE_COUNT%<br /><br />
                        <input type="button" name="RestoreDefaultPostLike" value="<?php _e('Restore Default Template', 'google-reader-stats'); ?>" onclick="grs_default_templates('post_like');" class="button" />
                    </th>
                    <th scope="row">
                        <textarea style="direction:ltr;" cols="80" rows="4"  id="grs_template_post_like" name="post_plusone_template"><?php echo htmlspecialchars(stripslashes($grs_options['post_plusone_template'])); ?></textarea>
                        </td>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <b><?php _e('Most +1ed Widget template:', 'google-reader-stats'); ?></b><br />
                        <?php _e('Allowed Variables:', 'google-reader-stats'); ?>
                <p style="direction:ltr;text-align:left;">
                        						- %PLUSONE_COUNT%<br />
                        						- %POST_TITLE%<br />
                        						- %POST_EXCERPT%<br />
                        						- %POST_CONTENT%<br />
                        							- %POST_URL%<br />
                </p>
                <input type="button" name="RestoreDefault" value="<?php _e('Restore Default Template', 'google-reader-stats'); ?>" onclick="grs_default_templates('most_liked');" class="button" />
                </th>
                <th scope="row">
                    <textarea style="direction:ltr;" cols="80" rows="4"  id="grs_template_most_liked" name="most_liked_template"><?php echo htmlspecialchars(stripslashes($grs_options['most_liked_template'])); ?></textarea>
                </th>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <b><?php _e('Post view template:', 'google-reader-stats'); ?></b><br />
                        <?php _e('Allowed Variables:', 'google-reader-stats'); ?><br />
                        						- %VIEW_COUNT%<br /><br />
                        <input type="button" name="RestoreDefaultPostView" value="<?php _e('Restore Default Template', 'google-reader-stats'); ?>" onclick="grs_default_templates('post_view');" class="button" />
                    </th>
                    <th scope="row">
                        <textarea style="direction:ltr;" cols="80" rows="4"  id="grs_template_post_view" name="post_view_template"><?php echo htmlspecialchars(stripslashes($grs_options['post_view_template'])); ?></textarea>
                        </td>
                </tr>
                <tr valign="top">
                    <th scope="row">
                        <b><?php _e('Most Visited Widget template:', 'google-reader-stats'); ?></b><br />
                        <?php _e('Allowed Variables:', 'google-reader-stats'); ?>
                <p style="direction:ltr;text-align:left;">
                        						- %VIIEW_COUNT%<br />
                        						- %POST_TITLE%<br />
                        						- %POST_EXCERPT%<br />
                        						- %POST_CONTENT%<br />
                        							- %POST_URL%<br />
                </p>
                <input type="button" name="RestoreDefaultMostViewd" value="<?php _e('Restore Default Template', 'google-reader-stats'); ?>" onclick="grs_default_templates('most_viewed');" class="button" />
                </th>
                <th scope="row">
                    <textarea style="direction:ltr;" cols="80" rows="4"  id="grs_template_most_viewed" name="most_viewd_template"><?php echo htmlspecialchars(stripslashes($grs_options['most_viewd_template'])); ?></textarea>
                </th>
                </tr>
            </table>
            <h3><?php _e('Spread the Plugin', 'google-reader-stats'); ?></h3>
            <p><input name="show_plugin_url" value="true" type="checkbox" <?php if ($grs_options['show_plugin_url'] == 'true')
                        echo ' checked="checked" '; ?> /> <?php _e('Show Plugin Url.', 'google-reader-stats'); ?></p>
            <p><input name="show_author_url" value="true" type="checkbox" <?php if ($grs_options['show_author_url'] == 'true')
                      echo ' checked="checked" '; ?> /> <?php _e('Show Author Url.', 'google-reader-stats'); ?></p>
            <div class="submit">
                <input class="button-primary" type="submit" name="update_google_reader_stats_settings" value="<?php _e('Save Changes', 'google-reader-stats') ?>" />
            </div>
            <hr />
            <div>
                <h4><?php _e('My other plugins for wordpress:', 'google-reader-stats'); ?></h4>
                <ul>
                    <li><b>- <?php _e('Google Transliteration ', 'google-reader-stats'); ?></b>
                        						(<a href="http://wordpress.org/extend/plugins/google-transliteration/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/en/blog/2009/10/10/google-transliteration-for-wordpress/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>
                    <li><b>- <?php _e('Likekhor ', 'google-reader-stats'); ?></b>
                        						(<a href="http://wordpress.org/extend/plugins/wp-likekhor/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/blog/1389/04/30/%D9%85%D8%B9%D8%B1%D9%81%DB%8C-%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D9%84%D8%A7%DB%8C%DA%A9-%D8%AE%D9%88%D8%B1-%D9%88%D8%B1%D8%AF%D9%BE%D8%B1%D8%B3/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>						
                    <li>- <b><?php _e('Advanced User Agent Displayer ', 'google-reader-stats'); ?></b>
                        						(<a href="http://wordpress.org/extend/plugins/advanced-user-agent-displayer/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/en/blog/2009/09/20/advanced-user-agent-displayer/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>						
                    <li>- <b><?php _e('Comments On Feed ', 'google-reader-stats'); ?></b>
                        						(<a href="http://wordpress.org/extend/plugins/comments-on-feed/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/en/blog/2009/12/18/comments-on-feed-for-wordpress/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>
                    <li><b>- <?php _e('Behnevis Transliteration ', 'google-reader-stats'); ?></b> 
                        						(<a href="http://wordpress.org/extend/plugins/behnevis-transliteration/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="http://www.moallemi.ir/blog/1388/07/25/%D8%A7%D9%81%D8%B2%D9%88%D9%86%D9%87-%D9%86%D9%88%DB%8C%D8%B3%D9%87-%DA%AF%D8%B1%D8%AF%D8%A7%D9%86-%D8%A8%D9%87%D9%86%D9%88%DB%8C%D8%B3-%D8%A8%D8%B1%D8%A7%DB%8C-%D9%88%D8%B1%D8%AF%D9%BE%D8%B1%D8%B3/"><?php _e('More Information', 'google-reader-stats'); ?></a> )
                    </li>
                    <li><b>- <?php _e('Feed Delay ', 'google-reader-stats'); ?></b> 
                        						(<a href="http://wordpress.org/extend/plugins/feed-delay/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/en/blog/2010/02/25/feed-delay-for-wordpress/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>
                    <li><b>- <?php _e('Contact Commenter ', 'google-reader-stats'); ?></b> 
                        						(<a href="http://wordpress.org/extend/plugins/contact-commenter/"><?php _e('Download', 'google-reader-stats'); ?></a> | 
                        <a href="<?php _e('http://www.moallemi.ir/blog/1388/12/27/%d9%87%d8%af%db%8c%d9%87-%da%a9%d8%a7%d9%88%d8%b4%da%af%d8%b1-%d9%85%d9%86%d8%a7%d8%b3%d8%a8%d8%aa-%d8%b3%d8%a7%d9%84-%d9%86%d9%88-%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3/', 'google-reader-stats'); ?>"><?php _e('More Information', 'google-reader-stats'); ?></a>)
                    </li>
                </ul>
            </div>
        </form>
    </div>
    <script type="text/javascript" src="<?php echo $plugin_url ?>/jquery.validate.min.js"></script>
    <script type="text/javascript">
        /* <![CDATA[*/
        function grs_default_templates(template) {
            var default_template;
            switch(template) {
                case 'post_like':
                    default_template = " <img align=\"absmiddle\" src=\"<?php echo $plugin_url; ?>/grs_plusone_small.png\" alt=\"like\" /> %PLUSONE_COUNT% ";
                    break;
                case 'most_liked':
                    default_template = "<li><a href=\"%POST_URL%\"  title=\"%POST_TITLE%\">%POST_TITLE%</a> - <img align=\"absmiddle\" src=\"<?php echo $plugin_url; ?>/grs_plusone_small.png\" alt=\"like\" /> %PLUSONE_COUNT% <?php _e('likes', 'google-reader-stats'); ?></li>";
                    break;
                case 'post_view':
                    default_template = " <img align=\"absmiddle\" src=\"<?php echo $plugin_url; ?>/grs_views.gif\" alt=\"view\" /> %VIEW_COUNT% ";
                    break;
                case 'most_viewed':
                    default_template = "<li><a href=\"%POST_URL%\"  title=\"%POST_TITLE%\">%POST_TITLE%</a> - %VIEW_COUNT% <?php _e('views', 'google-reader-stats'); ?></li>";
                    break;
                }
                jQuery("#grs_template_" + template).val(default_template);
            }
                        		
            function hideAccount() {
                var status = jQuery('input[name="plusone_counter_enabled"]').is(':checked');
                if(!status) {
                    jQuery('#divCounter').hide('slow');
                    jQuery('#grs_mainform').unbind();
                }
                else {
                    jQuery('#divCounter').show('slow');
                    form_validate();
                }
            }
                        		
            jQuery(document).ready(function() {
    <?php if ($grs_options['plusone_counter_enabled'] == "true") { ?>
                    form_validate();
    <?php } ?>
            });
                        		
            function form_validate() {
                jQuery("#grs_mainform").validate({
                    rules: {
                        interval: {
                            required: true,
                            number: true,
                            min: 1
                        },
                        plusone_minimum: {
                            required: true,
                            number: true,
                            min: 0
                        },
                        view_minimum: {
                            required: true,
                            number: true,
                            min: 0
                        }
                    },
                    messages: {
                        interval: {
                            required : '<?php _e('Required.', 'google-reader-stats'); ?>',
                            number: '<?php _e('Enter a valid number.', 'google-reader-stats'); ?>',
                            min: '<?php _e('Enter a value greater than {0} or equal to {0}', 'google-reader-stats'); ?>'
                        },
                        plusone_minimum: {
                            required : '<?php _e('Required.', 'google-reader-stats'); ?>',
                            number: '<?php _e('Enter a valid number.', 'google-reader-stats'); ?>',
                            min: '<?php _e('Enter a value greater than {0} or equal to {0}', 'google-reader-stats'); ?>'
                        },
                        view_minimum: {
                            required : '<?php _e('Required.', 'google-reader-stats'); ?>',
                            number: '<?php _e('Enter a valid number.', 'google-reader-stats'); ?>',
                            min: '<?php _e('Enter a value greater than {0} or equal to {0}', 'google-reader-stats'); ?>'
                        }
                    }
                });
            }
            /* ]]> */
    </script>
    <?php
}

$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'google_reader_stats_links');

function google_reader_stats_links($links) {
    $settings_link = '<a href="options-general.php?page=google-reader-stats">' . __('Settings', 'google-reader-stats') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

function the_grs_likes() {
    $likes = intval(post_custom('grslike'));
    $options = get_option('google_reader_stats_options');
    $output = stripslashes($options['post_plusone_template']);
    $output = str_replace("%PLUSONE_COUNT%", number_format_i18n($likes), $output);
    if ($likes > $options['plusone_minimum'])
        echo apply_filters('the_grs_likes', $output);
    else
        return '';
}

function the_grs_plusones() {
    $likes = intval(post_custom('grsplusone'));
    $options = get_option('google_reader_stats_options');
    $output = stripslashes($options['post_plusone_template']);
    $output = str_replace("%PLUSONE_COUNT%", number_format_i18n($likes), $output);
    if ($likes > $options['plusone_minimum'])
        echo apply_filters('the_grs_plusones', $output);
    else
        return '';
}

function the_grs_views() {
    $views = intval(post_custom('grsview'));
    $options = get_option('google_reader_stats_options');
    $output = stripslashes($options['post_view_template']);
    $output = str_replace("%VIEW_COUNT%", number_format_i18n($views), $output);
    if ($views > $options['view_minimum'])
        echo apply_filters('the_grs_views', $output);
    else
        return '';
}

function grs_fetch_stats() {

    $options = get_google_reader_stats_options();
    //print '<pre dir="ltr">';
    //print_r($options);die;

    if (!function_exists('curl_init')) {
        $options['plugin_status'] = "CURL_MISSED";
        update_option('google_reader_stats_options', $options);

        if (is_admin()) {
            //print_r($options);
            ?>
            <div class="error">
                <p>
                    <?php _e("<em>cURL</em> missed. You can not use the +1 counter module of Google Reader Stats", 'google-reader-stats'); ?>
                </p>
            </div>
            <?php
        }
        return;
    }

    query_posts(array('posts_per_page' => 20,));
    if (have_posts()) {
        while (have_posts()) {
            the_post();
            $plusone = grs_fetch_item(get_the_ID());
            update_post_meta(get_the_ID(), 'grsplusone', $plusone);
        }
    }
    wp_reset_query();

    $options['last_update'] = date('Y-m-d H:i:s');
    update_option('google_reader_stats_options', $options);
}

function grs_fetch_item($post_id) {

    $url = get_permalink($post_id);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://clients6.google.com/rpc?key=AIzaSyCKSbrvQasunBoV16zDH9R33D88CeLr9gQ");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"' . $url . '","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));


    $curl_results = curl_exec($ch);
    curl_close($ch);

    $parsed_results = json_decode($curl_results, true);

    return $parsed_results[0]['result']['metadata']['globalCounts']['count'];
}

class WP_Widget_GoogleReaderStats extends WP_Widget {

    function WP_Widget_GoogleReaderStats() {
        $widget_ops = array('description' => __('Google Reader Statistics for wordpress', 'google-reader-stats'));
        $this->WP_Widget('grs', __('Google Reader Stats', 'google-reader-stats'), $widget_ops);
    }

    function widget($args, $instance) {
        extract($args);
        $title = empty($instance['title']) ? __('Google Reader Stats', 'google-reader-stats') : apply_filters('widget_title', $instance['title']);
        $type = esc_attr($instance['type']);
        $limit = intval($instance['limit']);
        $chars = intval($instance['chars']);
        echo $before_widget . $before_title . $title . $after_title;
        echo '<ul>' . "\n";
        switch ($type) {
            case 'most_liked':
                grs_get_most_liked($limit, $chars);
                break;
            case 'most_viewed':
                grs_get_most_viewed($limit, $chars);
                break;
        }
        echo '</ul>' . "\n";
        echo $after_widget;
    }

    function update($new_instance, $old_instance) {
        if (!isset($new_instance['submit'])) {
            return false;
        }
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['type'] = strip_tags($new_instance['type']);
        $instance['limit'] = intval($new_instance['limit']);
        $instance['chars'] = intval($new_instance['chars']);
        return $instance;
    }

    function form($instance) {
        global $wpdb;
        $instance = wp_parse_args((array) $instance, array('title' => __('Most +1ed in Google Reader', 'google-reader-stats'), 'type' => 'most_viewed', 'limit' => 10, 'chars' => 200));
        $title = esc_attr($instance['title']);
        $type = esc_attr($instance['type']);
        $limit = intval($instance['limit']);
        $chars = intval($instance['chars']);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'google-reader-stats'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('type'); ?>"><?php _e('Statistics Type:', 'google-reader-stats'); ?>
                <select name="<?php echo $this->get_field_name('type'); ?>" id="<?php echo $this->get_field_id('type'); ?>" class="widefat">
                    <option value="most_liked"<?php selected('most_liked', $type); ?>><?php _e('Most +1 ed', 'google-reader-stats'); ?></option>
                    <option value="most_viewed"<?php selected('most_viewed', $type); ?>><?php _e('Most Viewed', 'google-reader-stats'); ?></option>
                </select>
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('limit'); ?>"><?php _e('No. Of Posts To Show:', 'google-reader-stats'); ?> <input class="widefat" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('chars'); ?>"><?php _e('Maximum Post Title Length (Characters):', 'google-reader-stats'); ?> <input class="widefat" id="<?php echo $this->get_field_id('chars'); ?>" name="<?php echo $this->get_field_name('chars'); ?>" type="text" value="<?php echo $chars; ?>" /></label><br />
            <small><?php _e('<strong>0</strong> to disable.', 'google-reader-stats'); ?></small>
        </p>
        <input type="hidden" id="<?php echo $this->get_field_id('submit'); ?>" name="<?php echo $this->get_field_name('submit'); ?>" value="1" />
        <?php
    }

}

function grs_date($format, $date = 'now', $string = true) {
    if ($string)
        $date = strtotime($date);
    if (function_exists('jdate'))
        return jdate($format, $date);
    else
        return date($format, $date);
}

add_action('widgets_init', 'widget_grs_init');

function widget_grs_init() {
    register_widget('WP_Widget_GoogleReaderStats');
}

GoogleReaderStats();

function grs_get_most_liked($limit = 10, $chars = 0, $display = true) {
    global $wpdb, $post;
    $options = get_option('google_reader_stats_options');
    $temp = '';
    $output = '';
    $most_liked = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS grslike FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE post_date < '" . current_time('mysql') . "' AND post_status = 'publish' AND meta_key = 'grsplusone' AND post_password = '' ORDER  BY grslike DESC LIMIT $limit");

    if ($most_liked) {
        foreach ($most_liked as $post) {
            $post_likes = intval($post->grslike);
            $post_title = get_the_title();
            if ($chars > 0) {
                $post_title = grs_snippet_text($post_title, $chars);
            }
            $post_excerpt = grs_post_excerpt($post->post_excerpt, $post->post_content, $post->post_password, $chars);
            $post_content = get_the_content();
            $temp = stripslashes($options['most_liked_template']);
            $temp = str_replace("%PLUSONE_COUNT%", number_format_i18n($post_likes), $temp);
            $temp = str_replace("%POST_TITLE%", $post_title, $temp);
            $temp = str_replace("%POST_EXCERPT%", $post_excerpt, $temp);
            $temp = str_replace("%POST_CONTENT%", $post_content, $temp);
            $temp = str_replace("%POST_URL%", get_permalink(), $temp);
            $output .= $temp;
        }
        if ($options['show_plugin_url'] == 'true' or $options['show_author_url'] == 'true')
            $output .= '<p style="border-top:1px solid #EEEEEE" />';
        if ($options['show_plugin_url'] == 'true')
            $output .= '<span style="font-size:8pt;">' . __('Powerd by ', 'google-reader-stats') . '<a style="font-size:7pt;" href="http://wordpress.org/extend/plugins/google-reader-stats/">' . __('GRS', 'google-reader-stats') . '</a></span> ';
        if ($options['show_author_url'] == 'true')
            $output .= '<span style="font-size:8pt;">' . __('by ', 'google-reader-stats') . '<a style="font-size:7pt;" href="' . __('http://www.moallemi.ir/en', 'google-reader-stats') . '">' . __('Kavoshgar', 'google-reader-stats') . '</a></span>';
    }
    else {
        $output = '<li>' . __('N/A', 'google-reader-stats') . '</li>' . "\n";
    }
    if ($display) {
        echo $output;
    } else {
        return $output;
    }
}

function grs_get_most_viewed($limit = 10, $chars = 0, $display = true) {
    global $wpdb, $post;
    $options = get_option('google_reader_stats_options');
    $temp = '';
    $output = '';
    $most_viewed = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS grsview FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE post_date < '" . current_time('mysql') . "' AND post_status = 'publish' AND meta_key = 'grsview' AND post_password = '' ORDER  BY grsview DESC LIMIT $limit");
    if ($most_viewed) {
        foreach ($most_viewed as $post) {
            $post_views = intval($post->grsview);
            $post_title = get_the_title();
            if ($chars > 0) {
                $post_title = grs_snippet_text($post_title, $chars);
            }
            $post_excerpt = grs_post_excerpt($post->post_excerpt, $post->post_content, $post->post_password, $chars);
            $post_content = get_the_content();
            $temp = stripslashes($options['most_viewd_template']);
            $temp = str_replace("%VIEW_COUNT%", number_format_i18n($post_views), $temp);
            $temp = str_replace("%POST_TITLE%", $post_title, $temp);
            $temp = str_replace("%POST_EXCERPT%", $post_excerpt, $temp);
            $temp = str_replace("%POST_CONTENT%", $post_content, $temp);
            $temp = str_replace("%POST_URL%", get_permalink(), $temp);
            $output .= $temp;
        }
        if ($options['show_plugin_url'] == 'true' or $options['show_author_url'] == 'true')
            $output .= '<p style="border-top:1px solid #EEEEEE" />';
        if ($options['show_plugin_url'] == 'true')
            $output .= '<span style="font-size:8pt;">' . __('Powerd by ', 'google-reader-stats') . '<a style="font-size:7pt;" href="http://wordpress.org/extend/plugins/google-reader-stats/">' . __('GRS', 'google-reader-stats') . '</a></span> ';
        if ($options['show_author_url'] == 'true')
            $output .= '<span style="font-size:8pt;">' . __('by ', 'google-reader-stats') . '<a style="font-size:7pt;" href="' . __('http://www.moallemi.ir/en', 'google-reader-stats') . '">' . __('Kavoshgar', 'google-reader-stats') . '</a></span>';
    }
    else {
        $output = '<li>' . __('N/A', 'google-reader-stats') . '</li>' . "\n";
    }
    if ($display) {
        echo $output;
    } else {
        return $output;
    }
}

function grs_post_excerpt($post_excerpt, $post_content, $post_password, $chars = 200) {
    if (!empty($post_password)) {
        if (!isset($_COOKIE['wp-postpass_' . COOKIEHASH]) || $_COOKIE['wp-postpass_' . COOKIEHASH] != $post_password) {
            return __('There is no excerpt because this is a protected post.', 'google-reader-stats');
        }
    }
    if (empty($post_excerpt)) {
        return grs_snippet_text(strip_tags($post_content), $chars);
    } else {
        return $post_excerpt;
    }
}

function grs_snippet_text($text, $length = 0) {
    if (defined('MB_OVERLOAD_STRING')) {
        $text = @html_entity_decode($text, ENT_QUOTES, get_option('blog_charset'));
        if (mb_strlen($text) > $length) {
            return htmlentities(mb_substr($text, 0, $length), ENT_COMPAT, get_option('blog_charset')) . '...';
        } else {
            return htmlentities($text, ENT_COMPAT, get_option('blog_charset'));
        }
    } else {
        $text = @html_entity_decode($text, ENT_QUOTES, get_option('blog_charset'));
        if (strlen($text) > $length) {
            return htmlentities(substr($text, 0, $length), ENT_COMPAT, get_option('blog_charset')) . '...';
        } else {
            return htmlentities($text, ENT_COMPAT, get_option('blog_charset'));
        }
    }
}

function grs_add_counter_to_feed($content) {
    if (!is_feed())
        return $content;
    $google_reader_stats_options = get_google_reader_stats_options();
    $plugin_url = get_option('siteurl') . '/wp-content/plugins/' . plugin_basename(dirname(__FILE__));
    global $id;
    $counter_str = '<img width="6" height="5" src="' . $plugin_url . '/google-reader-view.php?id=' . $id . '" />';

    return $content . $counter_str;
}




function grs_manage_posts_columns($columns) {

    $columns['plusone'] = '+1';
    return $columns;
}


function grs_manage_posts_custom_column($name) {
    $options = get_google_reader_stats_options();
    global $post;
    switch ($name) {
        case 'plusone':
            if($options['plusone_column_type'] == 'button') {
                ?>
                <g:plusone href="<?php the_permalink(); ?>" callback="google_plus_one_log"></g:plusone>
                <?php
            } else {
                $url = get_permalink($post->ID);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, "https://clients6.google.com/rpc?key=AIzaSyCKSbrvQasunBoV16zDH9R33D88CeLr9gQ");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"' . $url . '","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));


                $curl_results = curl_exec($ch);
                curl_close($ch);

                $parsed_results = json_decode($curl_results, true);

                echo intval($parsed_results[0]['result']['metadata']['globalCounts']['count']);
            }

            break;
    }
}

function grs_ncall() {
    __("This plugin adds the Google Reader Stats (+1 count and Post Views) to your blog posts. Put the <code>&lt;?php if (function_exists( 'the_grs_plusones' )) the_grs_plusones(); ?&gt;</code> code for post +1s and  <code>&lt;?php if (function_exists( 'the_grs_views' )) the_grs_views(); ?&gt;</code> for post views in your template files (index.php, single.php, archive.php) to show +1/view count.", 'extended-gravatar');
    __('Reza Moallemi', 'extended-gravatar');
}

add_action('admin_head-edit.php', 'grs_admin_head');

function grs_admin_head() {
    ?>
    <script type="text/javascript" src="http://apis.google.com/js/plusone.js">
            <?php if(WPLANG == "fa_IR") echo "{lang: 'fa'}"; ?>
    </script>
    <?php
}