<div class="wrap">
    <div id="icon-options-general" class="icon32"><br /></div>
    <h2><?php _e('Google Reader Stat', 'google-reader-stats'); ?></h2>
    <?php
    $page_url = 'admin.php?page=' . plugin_basename(dirname(__FILE__)) . '/google-reader-view-stats.php';
    if (isset($_GET['date']) and $_GET['date'] != '') {
        $date = $_GET['date'];
        $stats = $wpdb->get_results("SELECT post_id, visit, post_title, post_date FROM {$wpdb->prefix}grs_main AS g JOIN {$wpdb->prefix}posts AS p ON g.post_id = p.ID WHERE date_visit = '$date' ORDER BY visit DESC;");
        ?>
        <h3><?php _e('Feed View Stats', 'google-reader-stats');
    echo " " . grs_date('d M Y', $_GET['date']); ?> </h3>
        <table class="widefat" width="100%">
            <thead>
                <tr>
                    <th><?php _e('Post', 'google-reader-stats'); ?></th>
                    <th style="width:20%;"><?php _e('Publish Date', 'google-reader-stats'); ?></th>
                    <th style="width:10%;"><?php _e('Feed View', 'google-reader-stats'); ?></th>
                </tr>
            </thead>
            <?php
            if ($stats) {
                $i = 0;

                foreach ($stats as $post) {
                    $feed_views = number_format_i18n($post->visit);
                    $post_date = grs_date('d M Y', $post->post_date);
                    if ($i % 2 == 0)
                        $style = '';
                    else
                        $style = ' class="alternate"';
                    echo "<tr $style>\n";
                    echo "<td><a href=\"" . home_url("/?p=$post->post_id") . "\">$post->post_title</a></td>\n";
                    echo "<td>$post_date</td>\n";
                    echo "<td>$feed_views</td>\n";
                    echo '</tr>';
                    $i++;
                    $total_fvisit += $post->visit;
                }
                echo "<tr style='background-color: #FFFFE0;'>\n";
                echo "<td><b>Total</b></td>\n";
                echo "<td></td>\n";
                echo "<td><b>$total_fvisit</b></td>\n";
                echo '</tr>';
            } else {
                echo '<tr><td align="center"><strong>' . __('N/A', 'google-reader-stats') . '</strong></td></tr>';
            }
            ?>
        </table>
        <?php
    } else {


        $posts = $wpdb->get_results("SELECT post_date FROM {$wpdb->posts}  WHERE post_status = 'publish' AND post_type = 'post' GROUP BY date(post_date) ORDER BY post_date DESC LIMIT 30");

        foreach ($posts as $key => $pdate)
            $post_dates[] = grs_date('m-d', $pdate->post_date);


        $fstats = $wpdb->get_results("SELECT sum(visit) AS visit, date_visit FROM {$wpdb->prefix}grs_main GROUP BY date_visit ORDER BY date_visit DESC LIMIT 30");
        $fstats = array_reverse($fstats);
        $max = 0;
        $i = 1;
        foreach ($fstats as $key => $stat) {

            $fdate_visits[] = "[$i,\"" . grs_date('m-d', $stat->date_visit) . "\"]";

            if (in_array(grs_date('m-d', $stat->date_visit), $post_dates))
                $fpost_dates[] = "[$i," . ($stat->visit) . "]";

            $fvisits[] = "[$i," . $stat->visit . "]";

            $fslinks[] = "[\"" . date('Y-m-d', strtotime($stat->date_visit)) . "\"]";
            if ($max < $stat->visit)
                $max = $stat->visit;
            $i++;
        }
        $count_fvisit = count($fdate_visits);

        $fdate_visits = @implode(',', $fdate_visits);
        $fvisits = @implode(',', $fvisits);
        $fslinks = @implode(',', $fslinks);

        $fpost_dates = @implode(',', $fpost_dates);

        if (class_exists('statisticsView')) {
            $cy = new statisticsView();
            $cystats = $cy->getDaily(1);
            $count_cystats = count($cystats);
            $cystats = array_reverse($cystats);

            $j = 1;
            foreach ($cystats as $cy) {
                $cyvisit[] = "[$j," . $cy['value'] . "]";
                if ($max < $cy['value'])
                    $max = $cy['value'];
                $j++;
            }

            $x = 1;
            if ($count_fvisit != $count_cystats)
                for ($x; $x <= $count_fvisit - $count_cystats; $x++)
                    $cyvisits[] = "[$x,0]";

            foreach ($cystats as $cy) {
                $cyvisits[] = "[$x," . $cy['value'] . "]";
                if ($max < $cy['value'])
                    $max = $cy['value'];
                $x++;
            }

            $cyvisits = @implode(',', $cyvisits);
        }

        $max += 300;
        ?>
        <style>
            .tickLabel {
                -webkit-transform: rotate(315deg); 
                -moz-transform: rotate(315deg);
                -o-transform: rotate(315deg);
            }
            #tooltip {
                -moz-border-radius: 3px 3px 3px 3px;
                -webkit-border-radius: 3px 3px 3px 3px;
                border-radius: 3px 3px 3px 3px;
                -moz-box-shadow: 0 1px 1px #D0D0D0;
                box-shadow: 0 1px 1px #D0D0D0;
                background: none repeat scroll 0 0 #FFFFFF;
                border: 1px solid #AAAAAA;
                color: #999999;
                padding: 5px 7px;
            }

        </style>
        <div style="height:300px;margin-top:30px 0; padding:0 15%;">
            <script type="text/javascript" language="javascript" src="<?php echo trailingslashit(plugins_url('', __FILE__)) . 'jquery.flot.js'; ?>"></script>
            <script type="text/javascript" language="javascript" src="<?php echo trailingslashit(plugins_url('', __FILE__)) . 'jquery.flot.symbol.js'; ?>"></script>

            <div id="placeholder" style="width:600px;height:300px"></div>
            <p id="choices">نمایش:</p>
        </div>
        <script id="source" language="javascript" type="text/javascript">
            jQuery(function () {
                var links = [<?php echo $fslinks; ?>];
    		
                var datasets = { 
			'feed_view' : { data: [<?php echo $fvisits; ?>], 
				label: "<?php _e('Feed view per day', 'google-reader-stats');?>",
				color: "#6FC2FF"
				},
			<?php if($cyvisits): ?>	
			'hit_view' : { data: [<?php echo $cyvisits; ?>], 
				label: "<?php _e('Post view per day', 'google-reader-stats');?>",
				color: "#4DA74D"
				},
			<?php endif;?>	
			'post_date_view' : { data: [<?php echo $fpost_dates; ?>], 
				label: "<?php _e('Post published in this day', 'google-reader-stats');?>",
				color: "#9440ED",
				points: { show: true, symbol: "cross", radius: 4},
				lines: { show: false }
				}
			};
    					
                                // insert checkboxes 
                                var choiceContainer = jQuery("#choices");
                                jQuery.each(datasets, function(key, val) {
                                    choiceContainer.append('<br/><input type="checkbox" name="' + key +
                                        '" checked="checked" id="id' + key + '">' +
                                        '<label for="id' + key + '">'
                                        + val.label + '</label>');
                                });
                                choiceContainer.find("input").click(plotAccordingToChoices);
    		
                                var plot;

                                function showTooltip(x, y, contents) {
                                    jQuery('<div id="tooltip">' + contents + '</div>').css( {
                                        position: 'absolute',
                                        display: 'none',
                                        top: y ,
                                        left: x + 5,
                                        opacity: 0.90
                                    }).appendTo("body").fadeIn(200);
                                }

                                var previousPoint = null;
                                jQuery("#placeholder").bind("plothover", function (event, pos, item) {
                                    jQuery("#x").text(pos.x.toFixed(2));
                                    jQuery("#y").text(pos.y.toFixed(2));

                                    if (item) {
                                        if (previousPoint != item.datapoint) {
                                            previousPoint = item.datapoint;
    						
                                            jQuery("#tooltip").remove();
                                            y = item.datapoint[1];
    						
                                            showTooltip(item.pageX - 20, item.pageY - 40, y);
                                        }
                                    }
                                    else {
                                        jQuery("#tooltip").remove();
                                        previousPoint = null;            
                                    }
                                });

                                jQuery("#placeholder").bind("plotclick", function (event, pos, item) {
                                    if (item) {
                                        location.href = '<?php echo $page_url . '&date='; ?>' + links[item.dataIndex];
                                        plot.highlight(item.series, item.datapoint);
                                    }
                                });
    			
                                function plotAccordingToChoices() {
                                    var data = [];

                                    choiceContainer.find("input:checked").each(function () {
                                        var key = jQuery(this).attr("name");
                                        if (key && datasets[key])
                                            data.push(datasets[key]);
                                    });

                                    if (data.length > 0)
                                        jQuery.plot(jQuery("#placeholder"),
                                    data ,
                                    {
                                        series: {
                                            lines: { show: true },
                                            points: { show: true }
                                        },
                                        grid: { backgroundColor: { colors: ["white", "#EFEFEF"] }, hoverable: true, clickable: true },
                                        xaxis: {ticks: [<?php echo $fdate_visits; ?>],
                                            min:0,
                                            max:<?php echo $i; ?>
                                        },
                                        yaxis: { min: 0, max: <?php echo $max; ?> }
                                    });
                                }
    		
                                plotAccordingToChoices();
    		
                            });
        </script>
    <?php
    $like_order = "grslike";
    $view_order = "grsview";
    if (isset($_GET['like_order']) and $_GET['like_order'] == 'date')
        $like_order = 'post_date';
    if (isset($_GET['view_order']) and $_GET['view_order'] == 'date')
        $view_order = 'post_date';
    $most_liked = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS grslike FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE post_date < '" . current_time('mysql') . "' AND post_status = 'publish' AND meta_key = 'grsplusone' AND post_password = '' ORDER  BY $like_order DESC LIMIT 30");
    $most_viewed = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS grsview FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE post_date < '" . current_time('mysql') . "' AND post_status = 'publish' AND meta_key = 'grsview' AND post_password = '' ORDER  BY $view_order DESC LIMIT 30");
    ?>


        <h3 style="margin-top:100px;"><?php _e('+1 Stats', 'google-reader-stats'); ?></h3>
        <table class="widefat" width="100%">
            <thead>
                <tr>
                    <th><?php _e('Post', 'google-reader-stats'); ?></th>
                    <th style="width:15%;"><a href="<?php echo $page_url; ?>&like_order=date"><?php _e('Publish Date', 'google-reader-stats'); ?></a></th>
                    <th style="width:8%;"><a href="<?php echo $page_url; ?>&like_order=like"><?php _e('+1', 'google-reader-stats'); ?></a></th>
                </tr>
            </thead>
    <?php
    if ($most_liked) {
        $i = 0;
        foreach ($most_liked as $post) {
            $post_likes = intval($post->grslike);
            $post_date = grs_date('d M Y', $post->post_date);
            if ($i % 2 == 0)
                $style = '';
            else
                $style = ' class="alternate"';
            echo "<tr $style>\n";
            echo "<td><a href=\"" . get_permalink() . "\">$post->post_title</a></td>\n";
            echo "<td>$post_date</td>\n";
            echo "<td>$post_likes <img align=\"absmiddle\" src=\"".trailingslashit(plugins_url('', __FILE__)) . "grs_plusone_small.png\" /></td>\n";
            echo '</tr>';
            $i++;
        }
    } else {
        echo '<tr><td align="center"><strong>' . __('N/A', 'google-reader-stats') . '</strong></td></tr>';
    }
    ?>
        </table>
        <br />
        <h3><?php _e('Feed View Stats', 'google-reader-stats'); ?></h3>
        <table class="widefat" width="100%">
            <thead>
                <tr>
                    <th><?php _e('Post', 'google-reader-stats'); ?></th>
                    <th style="width:15%;"><a name="view" href="<?php echo $page_url; ?>&view_order=date#view"><?php _e('Publish Date', 'google-reader-stats'); ?></a></th>
                    <th style="width:8%;"><a href="<?php echo $page_url; ?>&view_order=view#view"><?php _e('Feed View', 'google-reader-stats'); ?></a></th>
                </tr>
            </thead>
    <?php
    if ($most_viewed) {
        $i = 0;
        foreach ($most_viewed as $post) {
            $post_views = number_format_i18n($post->grsview);
            $post_date = grs_date('d M Y', $post->post_date);
            if ($i % 2 == 0)
                $style = '';
            else
                $style = ' class="alternate"';
            echo "<tr $style>\n";
            echo "<td><a href=\"" . get_permalink() . "\">$post->post_title</a></td>\n";
            echo "<td>$post_date</td>\n";
            echo "<td>$post_views</td>\n";
            echo '</tr>';
            $i++;
        }
    } else {
        echo '<tr><td align="center"><strong>' . __('N/A', 'google-reader-stats') . '</strong></td></tr>';
    }
    ?>
        </table>

    <?php } ?>

</div>
