<?php

	require_once '../../../wp-load.php';
	$id = intval($_GET['id']);
	if($id == 0)
	{	
		@header("HTTP/1.1 400 Bad Request");
		die;
	}
	/* if($_SERVER['HTTP_REFERER'] == '')
	{
		@header("HTTP/1.1 405 Method Not Allowed");
		die;
	} */
	$prv_view = intval(get_post_meta($id, 'grsview', true));
	update_post_meta($id, 'grsview', $prv_view + 1);
	
	global $wpdb;
	
	$visit = $wpdb->get_var("SELECT visit FROM {$wpdb->prefix}grs_main WHERE post_id = $id AND date_visit = '".date('Y-m-d', strtotime('now'))."'");

	if(!isset($visit)) {
		$wpdb->insert($wpdb->prefix.'grs_main' , 
							array('post_id' => $id,
								  'date_visit' => date('Y-m-d', strtotime('now'))
								  )
							)
						;
	} 
	else {
		$visit = intval($visit) + 1;
		$wpdb->update($wpdb->prefix.'grs_main' , 
							array('visit' => "$visit"),
							array('post_id' => $id,
								   'date_visit' => date('Y-m-d', strtotime('now'))
								   )
						);
	}
	
	
	@header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
	@header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
	@header("Cache-Control: no-store, no-cache, must-revalidate");
	@header("Cache-Control: post-check=0, pre-check=0", false);
	@header("Pragma: no-cache");
	@header("Content-type: image/png");
	echo file_get_contents('grs_views.gif');
?>