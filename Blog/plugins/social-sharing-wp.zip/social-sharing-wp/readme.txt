===  Social  Sharing  ===
Contributors: Melinda2

Tags: bookmark, bookmarking, bookmarks, button, buzz, del.icio.us, Digg, e-mail, email, Facebook, google, google buzz, icon, icons, image, images, links, myspace, page, pages, plugin, Post, posts, Reddit, save, seo, Share, sharethis, sharing, social, social bookmarking, social bookmarks, statistics, stats, stumbleupon, technorati, twitter, widget, google plus, google +1
Tested up to: 3.2.1
Stable tag: 1.1



Adds a set of cool icons and widgets at the end of your post for your readers to share.

== Description ==

This plugin adds a set of cool icons and widgets at the end of your post for your readers to share. Widgets are Twitter, Facebook and Google +1. It supports large icons and small icons.

More info  :  http://pluginsite.info/plugin/social-sharing/

== Screenshots ==

Screenshots and more info in official page 

http://pluginsite.info/plugin/social-sharing/



