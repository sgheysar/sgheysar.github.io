=== Plugin Name ===
Contributors: moallemi
Donate link: http://www.moallemi.ir/
Tags: like, gravatar, gravatar like, کاوشگر, moallemi
Requires at least: WordPress 3.0
Tested up to: WordPress 3.2.1
Stable tag: "trunk"

A  Wordpress.com Like plugin for self hosted wordpress sites

== Description ==

A  Wordpress.com Like plugin for self hosted wordpress sites


== Installation ==

1. Upload `gravatar-like` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==

1. Front UI

== Changelog ==

= 0.1 =
* base version



