<?php 
@session_start();
require_once '../../../wp-load.php';
$id = intval($_GET['id']);
if($id == 0) die(__('Invalid request.'));
$post = get_post($id);
$pos = strpos($_SERVER["HTTP_REFERER"], get_settings('siteurl'));
if( $pos !== false)
{ ?>
	<div style="background-color:#FFFFE0;border:1px solid #E6DB55;padding:5px;">
	<b><?php _e('Your comment was sent successfully.', 'comments-on-feed'); ?></b>
		<div style="padding-top:5px;">
			<a style="text-decoration:none;color:green;" href="<?php the_permalink(); ?>" ><?php _e('View this post', 'comments-on-feed'); ?></a> | 
			<a style="text-decoration:none;" href="<?php the_permalink();?>/#comments" ><?php _e('View other comments', 'comments-on-feed'); ?></a> | 
			<a style="text-decoration:none;color:red;" href="#" onclick="window.open('','_self');window.close();"><?php _e('Close this window', 'comments-on-feed'); ?></a>
		</div>
	</div>
<?php
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title><?php echo get_settings('blogname'); ?> - <?php _e('Send comment for ', 'comments-on-feed'); the_title(); ?></title>
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php echo get_settings('blog_charset'); ?>" />
		<style type="text/css" media="screen">
		</style>
	</head>
	<body id="commentspopup" style="font-family:tahoma;font-size:8pt;" <?php if(WPLANG == 'fa_IR') echo 'dir="rtl"';?>>
		<!-- Comments On Feed 0.9.1.2 Developed By Reza Moallemi - http://www.moallemi.ir/blog -->
		<div id="comments">
			<?php
			// this line is WordPress' motor, do not delete it.
			$comment_author = (isset($_COOKIE['comment_author_' . COOKIEHASH])) ? trim($_COOKIE['comment_author_'. COOKIEHASH]) : '';
			$comment_author_email = (isset($_COOKIE['comment_author_email_'. COOKIEHASH])) ? trim($_COOKIE['comment_author_email_'. COOKIEHASH]) : '';
			$comment_author_url = (isset($_COOKIE['comment_author_url_'. COOKIEHASH])) ? trim($_COOKIE['comment_author_url_'. COOKIEHASH]) : '';
			$comments = get_approved_comments($id);
			$post = get_post($id);
			if (!empty($post->post_password) && $_COOKIE['wp-postpass_'. COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
				echo(get_the_password_form());
			} else { ?>
			<div id="comment-form">
				<div id="comment-form-inner">
				<?php if ('open' == $post->comment_status) { 
					
					$_SESSION['comments-on-feed'] = 'ok';					
				?>
					<h4><?php _e('Write a comment for "', 'comments-on-feed'); the_title(); ?> "</h4>
					<form action="<?php echo get_settings('siteurl'); ?>/wp-comments-post.php" method="post" id="comments-form">
						<p>
							<input style="font-family:tahoma;" type="text" name="author" id="author" class="textarea" value="<?php echo $comment_author; ?>" size="28" tabindex="1" />
							<label for="author"><?php _e('Name', 'comments-on-feed'); ?></label>
							<input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
							<input type="hidden" name="redirect_to" value="<?php echo wp_specialchars($_SERVER["REQUEST_URI"]); ?>" />
						</p>
						<p>
							<input style="font-family:tahoma;" type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="28" tabindex="2" />
							<label for="email"><?php _e('Email', 'comments-on-feed'); ?></label>
						</p>
						<p>
							<input style="font-family:tahoma;" type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="28" tabindex="3" />
							<label for="url"><?php _e('Site', 'comments-on-feed'); ?></label>
						</p>
						<p>
							<textarea style="font-family:tahoma;font-size:9pt;" name="comment" id="comment" cols="60" rows="4" tabindex="4"></textarea>
						</p>
						<p>
							<input name="submit" id="comment-submit" type="submit" tabindex="5" value="<?php _e('Send', 'comments-on-feed'); ?>" />
						</p>
					</form>
				<?php } else { // comments are closed ?>
				<p><?php _e('Comments are disable.', 'comments-on-feed'); ?></p>
				<?php }
				} // end password check
				?>
				</div>
			</div>
		</div>
	</body>
</html>