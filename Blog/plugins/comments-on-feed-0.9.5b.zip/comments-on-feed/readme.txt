﻿=== Plugin Name ===

Contributors: moallemi
Donate link: http://www.moallemi.ir/en/blog/2009/12/18/comments-on-feed-for-wordpress/
Tags: comment,comments,feed,custom feed, کاوشگر, google, google reader
Requires at least: 2.7.1
Tested up to: 3.0
Stable tag: "trunk"

This wordpress plugin lets your feed visitors write comments directly from your feed and shows each post comments on post feed item.


== Description ==

This wordpress plugin lets your feed visitors write comments directly from your feed and shows each post comments on post feed. There is no need for your feed subscribers to visit your blog post for reading commnets.


**Translations**

* Persian - [Reza Moallemi](http://www.moallemi.ir/)
* German - [Felix Griewald](http://www.felix-griewald.de)
* Polish - [Pawel Dworniak](http://www.dworniak.pl/)


**What's New in version 0.9.1.2**

	* Add German Translation

== Installation ==

1. Upload `comments-on-feed` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress


== Screenshots ==

1. A preview of "Quick Comment Button" in Google Reader
1. Options Page in Persian Language
1. Output in the Google Reader



== Changelog ==

= 0.9.1.2 =

* Add German Translation.

= 0.9.1.1 =

* Fixed a translation bug in English language. 

= 0.9.1 =

* Fixed a bug on showing "view more comments" options on the feed. 

= 0.9 =

* Add a graphical button for write comment link
* Add an option to set the button position
* Support for using your own buttons.

= 0.7.2 =

* Fixed a bug when the quick write button did not show on posts with no comments.

= 0.7.0.1 =

* Fixed a bug on e quick form template

= 0.7 =

* Add a quick form to write comments on each post.

* Add a link to view more comments on each post.

= 0.5.0.1 =

* Add Polish Translation

= 0.5 =

* base version







